#!/usr/bin/env python3
"""
Cylinder Spiral Maneuver Node with Live Depth, Width, and Height Plotting

Flight sequence:
  1. TAKEOFF: From landing (origin) hover at 2 m altitude.
  2. SEARCH_CYLINDER_1: Hover and turn left (yaw = +π/2) to detect cylinder 1 via /drone/front_depth.
     Estimate the cylinder's median depth, width (diameter), and height.
  3. SPIRAL_CYLINDER_1: Spiral around the detected cylinder 1 while ascending from 2 m to 12 m.
  4. RETURN_TO_LAND_CYL1: Return to the landing position and hover at 2 m.
  5. SEARCH_CYLINDER_2: Turn to look right (yaw = -π/2) to detect cylinder 2.
  6. SPIRAL_CYLINDER_2: Spiral around the detected cylinder 2 while ascending from 2 m to 12 m.
  7. RETURN_TO_ORIGIN_ASCEND: Return to the origin and ascend to 20 m.
  
Live Plotting:
  A matplotlib window opens (in interactive mode) and updates every second,
  showing a time-series of the estimated median depth, width (m), and height (m)
  from the detected cylinder.
  
Note: This code is for demonstration/learning purposes.
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
import math
import time
import cv2
import numpy as np
from cv_bridge import CvBridge
import matplotlib.pyplot as plt

# PX4 message types
from px4_msgs.msg import VehicleOdometry, OffboardControlMode, VehicleCommand, TrajectorySetpoint, VehicleStatus
from std_msgs.msg import Float64
from sensor_msgs.msg import Image

# Helper function to convert a quaternion to a yaw angle.
def quaternion_to_yaw(q):
    try:
        qw = q.w
        qx = q.x
        qy = q.y
        qz = q.z
    except Exception:
        qw, qx, qy, qz = q  # if provided as tuple/list
    siny = 2.0 * (qw * qz + qx * qy)
    cosy = 1.0 - 2.0 * (qy * qy + qz * qz)
    return math.atan2(siny, cosy)

class CylinderSpiralManeuver(Node):
    def __init__(self):
        super().__init__('cylinder_spiral_maneuver')
        
        # Default QoS for most topics
        qos_default = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        # For the depth camera, use VOLATILE durability (to match the publisher if needed)
        qos_depth = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # Publishers for offboard control, trajectory setpoints, and gimbal control.
        self.offboard_control_mode_pub = self.create_publisher(OffboardControlMode, '/fmu/in/offboard_control_mode', qos_default)
        self.trajectory_setpoint_pub = self.create_publisher(TrajectorySetpoint, '/fmu/in/trajectory_setpoint', qos_default)
        self.vehicle_command_pub = self.create_publisher(VehicleCommand, '/fmu/in/vehicle_command', qos_default)
        self.gimbal_yaw_pub = self.create_publisher(Float64, '/model/x500_gimbal_0/command/gimbal_yaw', 10)
        
        # Subscribers: vehicle odometry, depth camera, and vehicle status.
        self.vehicle_odometry_sub = self.create_subscription(VehicleOdometry, '/fmu/out/vehicle_odometry', self.odometry_callback, qos_default)
        self.depth_sub = self.create_subscription(Image, '/drone/front_depth', self.depth_callback, qos_depth)
        self.vehicle_status_sub = self.create_subscription(VehicleStatus, '/fmu/out/vehicle_status', self.status_callback, qos_default)
        
        self.bridge = CvBridge()
        
        # Variables to store sensor info and detection results.
        self.vehicle_odometry = None
        self.vehicle_status = None
        self.detected_cylinder = None  # will store median depth, width, and height
        self.current_cylinder_center = None  # estimated world coordinates of the cylinder
        
        # Flight parameters and state machine variables.
        self.state = "TAKEOFF"
        self.landing_pos = (0.0, 0.0)      # Landing at origin.
        self.takeoff_alt = 2.0             # 2 m altitude for takeoff/landing hover.
        self.spiral_end_alt = 12.0         # Altitude at the end of the spiral maneuver.
        self.final_alt = 20.0              # Final altitude after mission completion.
        self.spiral_radius = 5.0           # Radius of the spiral (meters).
        self.spiral_duration = 30.0        # Duration for each spiral (seconds).
        self.spiral_start_time = None      # To time the spiral maneuver.
        
        # Offboard mode and arming.
        self.setpoint_counter = 0
        
        self.timer_period = 0.05  # Main loop update (20 Hz).
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        
        # Live plotting: prepare a matplotlib figure to plot median depth, width, and height.
        self.plot_times = []
        self.median_depths = []
        self.widths = []
        self.heights = []
        plt.ion()
        self.fig, self.ax = plt.subplots()
        self.ax.set_title("Cylinder Measurements Over Time")
        self.ax.set_xlabel("Time (s)")
        self.ax.set_ylabel("Measurements (m)")
        self.plot_timer = self.create_timer(1.0, self.plot_callback)
        
        self.get_logger().info("CylinderSpiralManeuver node initialized.")

    def status_callback(self, msg):
        self.vehicle_status = msg

    def odometry_callback(self, msg):
        self.vehicle_odometry = msg
        self.update_gimbal()

    def depth_callback(self, msg):
        """
        Process the depth image from /drone/front_depth to detect the cylinder.
        Steps:
          - Convert the ROS depth image to an OpenCV image.
          - Apply median filtering and Canny edge detection.
          - Find the largest contour (assumed to be the cylinder) and compute its bounding box.
          - Estimate the median depth inside the bounding box.
          - Convert pixel dimensions (w, h) to meters using a pinhole camera model.
        """
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="32FC1")
        except Exception as e:
            self.get_logger().error("Depth image conversion error: " + str(e))
            return
        
        depth = cv_image.copy()
        depth_filtered = cv2.medianBlur(depth, 5)
        depth_norm = cv2.normalize(depth_filtered, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        edges = cv2.Canny(depth_norm, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(largest)
            # Extract the region of interest.
            region = depth_filtered[y:y+h, x:x+w]
            valid_region = region[region > 0]
            if valid_region.size > 0:
                median_depth = float(np.median(valid_region))
                # Convert pixel dimensions to meters using a pinhole camera model.
                focal_length = 525.0  # Adjust this based on your camera calibration.
                width_m = (w * median_depth) / focal_length
                height_m = (h * median_depth) / focal_length
                
                self.detected_cylinder = {
                    "median_depth": median_depth,
                    "width_m": width_m,
                    "height_m": height_m,
                    "bbox": (x, y, w, h)
                }
                # Update live plot data.
                t_now = time.time()
                self.plot_times.append(t_now)
                self.median_depths.append(median_depth)
                self.widths.append(width_m)
                self.heights.append(height_m)
            else:
                self.detected_cylinder = None
        else:
            self.detected_cylinder = None

    def update_gimbal(self):
        """
        Adjust the gimbal so that the front camera focuses on the target cylinder.
        For SEARCH states, command a fixed yaw:
          - SEARCH_CYLINDER_1: look left (yaw = +π/2)
          - SEARCH_CYLINDER_2: look right (yaw = -π/2)
        For SPIRAL states, if the cylinder center is known, point toward it.
        """
        if self.vehicle_odometry is None:
            return
        
        desired_yaw = 0.0
        if self.state == "SEARCH_CYLINDER_1":
            desired_yaw = math.pi / 2
        elif self.state == "SEARCH_CYLINDER_2":
            desired_yaw = -math.pi / 2
        elif self.state in ["SPIRAL_CYLINDER_1", "SPIRAL_CYLINDER_2"]:
            if self.current_cylinder_center is not None:
                drone_x = self.vehicle_odometry.position[0]
                drone_y = self.vehicle_odometry.position[1]
                center_x, center_y = self.current_cylinder_center
                desired_yaw = math.atan2(center_y - drone_y, center_x - drone_x)
            else:
                desired_yaw = 0.0
        else:
            desired_yaw = 0.0
        
        msg = Float64()
        msg.data = desired_yaw
        self.gimbal_yaw_pub.publish(msg)

    def arm(self):
        cmd = VehicleCommand()
        cmd.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
        cmd.param1 = 1.0  # Arm
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True
        cmd.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.vehicle_command_pub.publish(cmd)
        self.get_logger().info("Arm command sent.")

    def engage_offboard(self):
        cmd = VehicleCommand()
        cmd.command = VehicleCommand.VEHICLE_CMD_DO_SET_MODE
        cmd.param1 = 1.0
        cmd.param2 = 6.0  # Offboard mode
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True
        cmd.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.vehicle_command_pub.publish(cmd)
        self.get_logger().info("Offboard mode command sent.")

    def publish_offboard(self):
        msg = OffboardControlMode()
        msg.position = True
        msg.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.offboard_control_mode_pub.publish(msg)

    def publish_setpoint(self, x, y, z, yaw):
        sp = TrajectorySetpoint()
        sp.position = [x, y, z]
        sp.yaw = yaw
        sp.timestamp = int(self.get_clock().now().nanoseconds / 1000)
        self.trajectory_setpoint_pub.publish(sp)

    def get_drone_yaw(self):
        if self.vehicle_odometry is None:
            return 0.0
        try:
            return quaternion_to_yaw(self.vehicle_odometry.q)
        except Exception:
            return 0.0

    def timer_callback(self):
        self.setpoint_counter += 1
        if self.setpoint_counter == 10:
            self.engage_offboard()
            self.arm()
        self.publish_offboard()

        current_time = time.time()
        if self.vehicle_odometry is None:
            return

        drone_x = self.vehicle_odometry.position[0]
        drone_y = self.vehicle_odometry.position[1]
        try:
            current_alt = -self.vehicle_odometry.position[2]
        except Exception:
            current_alt = 0.0

        # State machine:
        if self.state == "TAKEOFF":
            # Take off to 2 m at the landing position.
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.takeoff_alt, 0.0)
            if abs(current_alt - self.takeoff_alt) < 0.3:
                self.get_logger().info("Takeoff complete. Transitioning to SEARCH_CYLINDER_1.")
                self.state = "SEARCH_CYLINDER_1"
                self.detected_cylinder = None

        elif self.state == "SEARCH_CYLINDER_1":
            # Hover at landing and look left (yaw = +π/2) to detect cylinder 1.
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.takeoff_alt, math.pi/2)
            if self.detected_cylinder is not None:
                median_depth = self.detected_cylinder["median_depth"]
                # Use the current drone yaw to estimate the cylinder's center in world coordinates.
                drone_yaw = self.get_drone_yaw()
                center_x = drone_x + median_depth * math.cos(drone_yaw)
                center_y = drone_y + median_depth * math.sin(drone_yaw)
                self.current_cylinder_center = (center_x, center_y)
                self.get_logger().info(f"Cylinder 1 detected at approx ({center_x:.2f}, {center_y:.2f}). Starting spiral.")
                self.spiral_start_time = current_time
                self.state = "SPIRAL_CYLINDER_1"

        elif self.state == "SPIRAL_CYLINDER_1":
            # Spiral around cylinder 1 while ascending from 2 m to 12 m.
            if self.current_cylinder_center is None:
                self.get_logger().warn("Cylinder 1 center unknown. Reverting to search.")
                self.state = "SEARCH_CYLINDER_1"
                return
            t_spiral = current_time - self.spiral_start_time
            omega = 2 * math.pi / self.spiral_duration
            center_x, center_y = self.current_cylinder_center
            x_set = center_x + self.spiral_radius * math.cos(omega * t_spiral)
            y_set = center_y + self.spiral_radius * math.sin(omega * t_spiral)
            target_alt = self.takeoff_alt + (self.spiral_end_alt - self.takeoff_alt) * min(t_spiral / self.spiral_duration, 1.0)
            yaw_set = math.atan2(center_y - drone_y, center_x - drone_x)
            self.publish_setpoint(x_set, y_set, -target_alt, yaw_set)
            self.get_logger().info(f"Spiraling Cylinder 1: t={t_spiral:.1f}s, alt={target_alt:.1f}m")
            if t_spiral >= self.spiral_duration:
                self.get_logger().info("Cylinder 1 spiral complete. Returning to landing position (2 m).")
                self.state = "RETURN_TO_LAND_CYL1"

        elif self.state == "RETURN_TO_LAND_CYL1":
            # Return to landing position and hover at 2 m.
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.takeoff_alt, 0.0)
            dist_to_land = math.hypot(drone_x - self.landing_pos[0], drone_y - self.landing_pos[1])
            if dist_to_land < 1.0 and abs(current_alt - self.takeoff_alt) < 0.5:
                self.get_logger().info("Landed at Cylinder 1 location. Transitioning to SEARCH_CYLINDER_2.")
                self.state = "SEARCH_CYLINDER_2"
                self.detected_cylinder = None

        elif self.state == "SEARCH_CYLINDER_2":
            # Hover and look right (yaw = -π/2) to detect cylinder 2.
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.takeoff_alt, -math.pi/2)
            if self.detected_cylinder is not None:
                median_depth = self.detected_cylinder["median_depth"]
                drone_yaw = self.get_drone_yaw()
                center_x = drone_x + median_depth * math.cos(drone_yaw)
                center_y = drone_y + median_depth * math.sin(drone_yaw)
                self.current_cylinder_center = (center_x, center_y)
                self.get_logger().info(f"Cylinder 2 detected at approx ({center_x:.2f}, {center_y:.2f}). Starting spiral.")
                self.spiral_start_time = current_time
                self.state = "SPIRAL_CYLINDER_2"

        elif self.state == "SPIRAL_CYLINDER_2":
            # Spiral around cylinder 2 while ascending from 2 m to 12 m.
            if self.current_cylinder_center is None:
                self.get_logger().warn("Cylinder 2 center unknown. Reverting to search.")
                self.state = "SEARCH_CYLINDER_2"
                return
            t_spiral = current_time - self.spiral_start_time
            omega = 2 * math.pi / self.spiral_duration
            center_x, center_y = self.current_cylinder_center
            x_set = center_x + self.spiral_radius * math.cos(omega * t_spiral)
            y_set = center_y + self.spiral_radius * math.sin(omega * t_spiral)
            target_alt = self.takeoff_alt + (self.spiral_end_alt - self.takeoff_alt) * min(t_spiral / self.spiral_duration, 1.0)
            yaw_set = math.atan2(center_y - drone_y, center_x - drone_x)
            self.publish_setpoint(x_set, y_set, -target_alt, yaw_set)
            self.get_logger().info(f"Spiraling Cylinder 2: t={t_spiral:.1f}s, alt={target_alt:.1f}m")
            if t_spiral >= self.spiral_duration:
                self.get_logger().info("Cylinder 2 spiral complete. Returning to origin and ascending to 20 m.")
                self.state = "RETURN_TO_ORIGIN_ASCEND"

        elif self.state == "RETURN_TO_ORIGIN_ASCEND":
            # Return to origin and climb to 20 m altitude.
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.final_alt, 0.0)
            dist_to_origin = math.hypot(drone_x - self.landing_pos[0], drone_y - self.landing_pos[1])
            if dist_to_origin < 1.0 and abs(current_alt - self.final_alt) < 0.5:
                self.get_logger().info("Mission complete: hovering at origin at 20 m altitude.")
                self.state = "HOVER"

        elif self.state == "HOVER":
            self.publish_setpoint(self.landing_pos[0], self.landing_pos[1], -self.final_alt, 0.0)
        else:
            self.get_logger().warn("Unknown state.")

    def plot_callback(self):
        # Update the live plot if we have measurements.
        if len(self.plot_times) > 0:
            self.ax.clear()
            self.ax.plot(self.plot_times, self.median_depths, marker='o', linestyle='-', label='Median Depth (m)')
            self.ax.plot(self.plot_times, self.widths, marker='s', linestyle='-', label='Width (m)')
            self.ax.plot(self.plot_times, self.heights, marker='^', linestyle='-', label='Height (m)')
            self.ax.set_title("Cylinder Measurements Over Time")
            self.ax.set_xlabel("Time (s)")
            self.ax.set_ylabel("Measurements (m)")
            self.ax.legend()
            plt.draw()
            plt.pause(0.001)

def main():
    rclpy.init()
    node = CylinderSpiralManeuver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Mission interrupted.")
    finally:
        node.destroy_node()
        rclpy.shutdown()
        plt.ioff()
        plt.show()

if __name__ == '__main__':
    main()
